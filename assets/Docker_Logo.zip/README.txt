                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1677398
Docker Logo by dlaguerre is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

EN : 
I made the Docker logo in 3D because it was not available.
It was created from the 2D logo, it is not necessarily consistent with the vision of the author.

FR : 

J'ai réalisé le logo de Docker en 3D car celui-ci n'était pas disponible. 

Il a été réalisé à partir du logo 2D, il n'est pas forcément conforme à la vision de l'auteur.


Docker website : https://www.docker.com



# Print Settings

Printer: iTopie
Rafts: Yes
Supports: Yes
Resolution: 1
Infill: 20%

Notes: 
I've sliced it with CraftWare. 

Hight 

# How I Designed This

## It was designated with Fusion 360


![Alt text](https://cdn.thingiverse.com/assets/cf/93/35/11/73/docker_Fusion_360.png)